<?php
// File: proses_pesanan.php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $pesan = trim($_POST['pesan']);
    $keranjang = json_decode($_POST['keranjang_data'], true);

    // Validasi sisi server (pengaman jika JS dimatikan)
    if (!empty($nama) && !empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($keranjang)) {
        
        $pesananBaru = [
            'nama' => htmlspecialchars($nama),
            'email' => htmlspecialchars($email),
            'pesan' => htmlspecialchars($pesan),
            'keranjang' => $keranjang
        ];

        if (!isset($_SESSION['semua_pesanan'])) {
            $_SESSION['semua_pesanan'] = [];
        }

        $_SESSION['semua_pesanan'][] = $pesananBaru;
        $_SESSION['status'] = 'sukses'; // Tandai sebagai sukses

    } else {
        // Jika validasi server gagal
        $_SESSION['status'] = 'error'; // Tandai sebagai error
    }
    
    // Alihkan ke halaman hasil untuk menampilkan status (sukses atau error)
    header('Location: hasil.php');
    exit();
}
?>